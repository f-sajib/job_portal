<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php require ('head.php') ?>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <?php require ('sidebar_menu.php'); ?>
        <!-- sidebar menu area end -->

        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <?php require ('header.php'); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
            <div class="row align-items-center">
                <div class="col-sm-12 ">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-left">Dashboard</h4>
                    <ul class="breadcrumbs pull-left">
                        <li><a href="#">Home</a></li>
                        <li><span>Edit Profile</span></li>
                    </ul>
                    <ul class="user-profile pull-right">
                        <img class="avatar user-thumb pull-left" src="<?php echo base_url(); ?>asset/img/<?php echo $info->photo; ?>" alt="avatar">
                        <h4 class="user-name dropdown-toggle pull-right" data-toggle="dropdown"> 
                        <?php echo $info->f_name; ?><i class="fa fa-angle-down"></i></h4>
                        <ul class="dropdown-menu">
                            <li class="dropdown-item"><a href="<?php echo site_url('Welcome/logOut')?>">Log Out</a></li>
                        </ul>
                    </ul>
                </div>
                </div>
            </div>    
            </div>
            <!-- page title area end -->



            <!-- =================================
            ================================== -->
            <br>
            <div class="main-content-inner">
            <h3 class="user-profile user-name">Complete Your Profile</h3>
            <br>
            <div class="row">
            <form enctype="multipart/form-data" name="add_edu" id="add_edu"
            action="<?php echo site_url('Dashboard/updatePfrofile')?>" method="POST">
                <div class="col-md-9">
                    <div class="form-group">
                        <label class="control-label col-sm-2">First Name</label>
                        <div class="col-sm-4"> 
                            <input name="edit_f_name" class="form-control" value="<?php echo $info->f_name; ?> ">
                        </div>
                        <label class="control-label col-sm-2">Last Name</label>
                        <div class="col-sm-4"> 
                            <input name="edit_l_name" class="form-control" value="<?php echo $info->l_name; ?> ">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Father's Name</label>
                        <div class="col-sm-4"> 
                            <input name="edit_father" class="form-control" value="<?php echo $info->father; ?> ">
                        </div>
                        <label class="control-label col-sm-2">Mother's Name</label>
                        <div class="col-sm-4"> 
                            <input name="edit_mother" class="form-control" value="<?php echo $info->mother; ?> ">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Date Of Birth</label>
                        <div class="col-sm-4"> 
                            <input  type="date" name="dob" class="form-control" value="<?php echo $info->date_of_birth; ?>">
                         </div>
<!--                         <label class="control-label col-sm-2">Contact</label>
                        <div class="col-sm-4">
                            
                        </div> -->
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Email</label>
                        <div class="col-sm-4"> 
                            <input type="email" name="edit_email" class="form-control" value="<?php echo $info->email; ?>">
                         </div>
                        <label class="control-label col-sm-2">Contact</label>
                        <div class="col-sm-4">
                            <input name="edit_mobile" class="form-control" value="<?php echo $info->mobile; ?>">
                         </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Present Address</label>
                        <div class="col-sm-10"> 
                                                      
                             <input  name="edit_pre_address" class="form-control" value="<?php echo $info->pre_address; ?>">

                         </div>
                   
                        <label class="control-label col-sm-2">Permanent Address</label>
                        <div class="col-sm-10"> 
                                
                                <input  name="edit_per_address" class="form-control" value="<?php echo $info->per_address; ?>">

                         </div>
                    </div>
                </div>
                <div class="col-md-3">
                   
                            <img class="img-responsive img-circle db-pf" src="<?php echo base_url(); ?>asset/img/<?php echo $info->photo; ?>" class="img-thumbnail">
                           
                   
                   <input class="user-profile" type="file" name="pic">
                   
                   
                </div>
             
            </div>
<div class="row">
                    <h3 class="col-sm-12 text-center">Update Educational Details</h3>
                    <div class="col-md-12 col-sm-12">
                    <table class="table table-bordered" id="dynamic_field" >
                       <!--  <tr class="dashboard_edu bg-success">
                            <th width="10%" style="text-align: center;">Degree</th>
                            <th width="10%">Passing Year</th>
                            <th width="30%">Board/City</th>
                            <th width="40%">Institute</th>
                            <th width="10%">Result</th>
                            <th><button type="button" name="add" id="add" class="btn btn-success">ADD</button></th>
                        </tr> -->
                         <tr class="dashboard_edu">
                            <td width="10%"><input id="degree" name="degree" class="form-control" placeholder="degree"></td>
                            <td width="10%"><input id="year" name="year" class="form-control" placeholder="year"></td>
                            <td width="30%"><input id="board" name="board" class="form-control" placeholder="board/city"></td>
                            <td width="40%"><input id="institute" name="institute" class="form-control" placeholder="institute"></td>
                            <td width="10%"><input id="result" name="result" class="form-control" placeholder="result"></td>
                             <td><button type="button" name="add" id="add" class="btn btn-success">ADD</button></td>
                         </tr>
                      
                    </table>
                    </div>
                </div> <br/>
                <button type="submit" id="submit" class="btn btn-success pull-right">Save</button>

               </form>
            </div>

            <!-- =================================
            ================================== -->

        </div>
        <!-- main content area end -->

        <!-- footer area start-->
        <footer>
            <?php require ('footer.php'); ?>
        </footer>
        <!-- footer area end-->
    </div>

    <!-- jquery latest version -->
    <script src="<?= base_url(); ?>asset/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="<?= base_url(); ?>asset/js/popper.min.js"></script>
    <script src="<?= base_url(); ?>asset/js/owl.carousel.min.js"></script>
    <script src="<?= base_url(); ?>asset/js/metisMenu.min.js"></script>
    <script src="<?= base_url(); ?>asset/js/jquery.slimscroll.min.js"></script>
    <script src="<?= base_url(); ?>asset/js/jquery.slicknav.min.js"></script>
    <script src="<?= base_url(); ?>asset/js/dashboard_plugins.js"></script>
    <script src="<?= base_url(); ?>asset/js/dashboard_scripts.js"></script>
    <script src="<?= base_url(); ?>asset/js/vendor/modernizr-2.8.3.min.js"></script><script>
    zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
    </script>

 <script>
$(document).ready(function(){
    var i=1;
    $('#add').click(function(){
        i++;
        $('#dynamic_field').append('<tr id="row'+i+'"><td width="10%"><input id="degree" name="degree[]" class="form-control" placeholder="degree"></td><td width="10%"><input id="year" name="year[]" class="form-control" placeholder="year"></td><td width="30%"><input id="board" name="board[]" class="form-control" placeholder="board/city"></td><td width="40%"><input id="institute" name="institute[]" class="form-control" placeholder="institute"></td><td width="10%"><input id="result" name="result[]" class="form-control" placeholder="result"></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
    });
    
    $(document).on('click', '.btn_remove', function(){
        var button_id = $(this).attr("id"); 
        $('#row'+button_id+'').remove();
    });

    $('#submit').click(function(){      
        $.ajax({
            url:"name.php",
            method:"POST",
            data:$('#add_edu').serialize(),
            success:function(data)
            {
                alert(data);
                $('#add_edu')[0].reset();
            }
        });
    });
    
});
</script>
</body>

</html>
